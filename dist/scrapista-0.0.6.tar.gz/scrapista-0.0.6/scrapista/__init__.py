from scrapista.amazon import AmazonScraper
from scrapista.imdb import ImdbScraper
from scrapista.wikipedia import WikiScraper
from scrapista.goodreads import GoodReadsScraper